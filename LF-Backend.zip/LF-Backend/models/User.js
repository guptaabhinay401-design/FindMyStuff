const mongoose = require("mongoose");

// Create schema for User collection
const UserSchema = new mongoose.Schema({

    // User full name
    name: {
        type: String,
        required: true
    },

    // User email (must be unique)
    email: {
        type: String,
        required: true,
        unique: true
    },

    // User password (will be stored as hashed password)
    password: {
        type: String,
        required: true
    },

    // User mobile number
    mobile: {
        type: String,
        default: ""
    },

    // Optional college identifier
    collegeId: {
        type: String,
        default: ""
    },

    // Optional profile image as URL or data URI
    profileImage: {
        type: String,
        default: ""
    },

    // Role of user (student or admin)
    role: {
        type: String,
        default: "student"
    },

    // User creation time
    createdAt: {
        type: Date,
        default: Date.now
    }

});

// Export model
module.exports = mongoose.model("User", UserSchema);
