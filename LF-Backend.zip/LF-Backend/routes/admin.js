const express = require("express");
const router = express.Router();

const Item = require("../models/Item");
const User = require("../models/User");
const authMiddleware = require("../middleware/authMiddleware");

function requireAdmin(req, res, next) {
  if (!req.user || !req.user.id) {
    return res.status(401).json({
      message: "Unauthorized"
    });
  }

  next();
}

router.get("/overview", authMiddleware, requireAdmin, async (req, res) => {
  try {
    const currentUser = await User.findById(req.user.id);

    if (!currentUser || currentUser.role !== "admin") {
      return res.status(403).json({
        message: "Admin access required"
      });
    }

    const [
      lostCount,
      foundCount,
      userCount,
      lostItems,
      foundItems,
      users
    ] = await Promise.all([
      Item.countDocuments({ type: "lost" }),
      Item.countDocuments({ type: "found" }),
      User.countDocuments(),
      Item.find({ type: "lost" }).sort({ date: -1 }).limit(10),
      Item.find({ type: "found" }).sort({ date: -1 }).limit(10),
      User.find().sort({ createdAt: -1 }).limit(10).select("name email role mobile createdAt profileImage")
    ]);

    res.json({
      counts: {
        lost: lostCount,
        found: foundCount,
        users: userCount,
        claims: 0
      },
      lostItems,
      foundItems,
      users
    });
  } catch (error) {
    res.status(500).json({
      message: "Server error"
    });
  }
});

module.exports = router;
