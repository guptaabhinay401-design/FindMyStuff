const express = require("express");
const router = express.Router();

const User = require("../models/User");

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const authMiddleware = require("../middleware/authMiddleware");

function sanitizeUser(user) {
    return {
        id: user._id,
        name: user.name || "",
        email: user.email || "",
        mobile: user.mobile || "",
        collegeId: user.collegeId || "",
        profileImage: user.profileImage || "",
        role: user.role || "student",
        createdAt: user.createdAt || null
    };
}

function normalizeOptionalText(value) {
    return String(value || "").trim();
}


// ===============================
// USER SIGNUP
// ===============================
router.post("/signup", async (req, res) => {

    try{

        const {name, email, password, mobile} = req.body;
        const normalizedEmail = normalizeOptionalText(email).toLowerCase();

        if (!normalizeOptionalText(name) || !normalizedEmail || !password || !normalizeOptionalText(mobile)) {
            return res.status(400).json({
                message: "Name, email, mobile and password are required"
            });
        }

        // Check if user already exists
        const existingUser = await User.findOne({email: normalizedEmail});

        if(existingUser){
            return res.status(400).json({
                message: "User already exists"
            });
        }

        // Hash the password before saving
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = new User({

            name: normalizeOptionalText(name),
            email: normalizedEmail,
            password: hashedPassword,
            mobile: normalizeOptionalText(mobile)

        });

        await newUser.save();

        res.status(201).json({
            message: "User registered successfully 🎉",
            user: sanitizeUser(newUser)
        });

    }

    catch(error){

        res.status(500).json({
            error: error.message
        });

    }

});


// ===============================
// USER LOGIN
// ===============================
router.post("/login", async (req, res) => {

    try{

        const {email, password} = req.body;
        const normalizedEmail = normalizeOptionalText(email).toLowerCase();

        if (!normalizedEmail || !password) {
            return res.status(400).json({
                message: "Email and password are required"
            });
        }

        // Find user by email
        const user = await User.findOne({email: normalizedEmail});

        if(!user){
            return res.status(400).json({
                message: "Invalid credentials"
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);

        if(!isMatch){
            return res.status(400).json({
                message: "Invalid credentials"
            });
        }

        // Create JWT token
        const token = jwt.sign(

            {
                id: user._id,
                email: user.email
            },

            process.env.JWT_SECRET,

            {
                expiresIn: "1d"
            }

        );

        res.json({

            message: "Login successful 🎉",
            token,
            user: sanitizeUser(user)

        });

    }

    catch(error){

        res.status(500).json({
            error: error.message
        });

    }

});


// ===============================
// GET CURRENT USER
// ===============================
router.get("/me", authMiddleware, async (req, res) => {

    try {

        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.json({
            user: sanitizeUser(user)
        });

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});


// ===============================
// UPDATE PROFILE
// ===============================
router.put("/profile", authMiddleware, async (req, res) => {

    try {

        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const nextEmail = normalizeOptionalText(req.body.email).toLowerCase();

        if (nextEmail && nextEmail !== user.email) {
            const existingUser = await User.findOne({ email: nextEmail });
            if (existingUser && String(existingUser._id) !== String(user._id)) {
                return res.status(400).json({
                    message: "Email already in use"
                });
            }
            user.email = nextEmail;
        }

        if (typeof req.body.name !== "undefined") {
            user.name = normalizeOptionalText(req.body.name);
        }

        if (typeof req.body.mobile !== "undefined") {
            user.mobile = normalizeOptionalText(req.body.mobile);
        }

        if (typeof req.body.collegeId !== "undefined") {
            user.collegeId = normalizeOptionalText(req.body.collegeId);
        }

        if (typeof req.body.profileImage !== "undefined") {
            user.profileImage = normalizeOptionalText(req.body.profileImage);
        }

        await user.save();

        res.json({
            message: "Profile updated successfully",
            user: sanitizeUser(user)
        });

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});


// ===============================
// CHANGE PASSWORD
// ===============================
router.put("/change-password", authMiddleware, async (req, res) => {

    try {

        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                message: "Current password and new password are required"
            });
        }

        if (String(newPassword).length < 6) {
            return res.status(400).json({
                message: "New password must be at least 6 characters"
            });
        }

        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const isMatch = await bcrypt.compare(currentPassword, user.password);

        if (!isMatch) {
            return res.status(400).json({
                message: "Current password is incorrect"
            });
        }

        user.password = await bcrypt.hash(newPassword, 10);
        await user.save();

        res.json({
            message: "Password changed successfully"
        });

    } catch (error) {

        res.status(500).json({
            error: error.message
        });

    }

});

module.exports = router;
