const express = require("express");
const router = express.Router();

const Item = require("../models/Item");

function toSafeDate(value) {
  if (!value) {
    return new Date();
  }

  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return new Date();
  }

  return parsed;
}

// API: Get all found items
router.get("/", async (req, res) => {

  try {

    const items = await Item
      .find({ type: "found" })
      .sort({ date: -1 });

    res.json(items);

  } catch (error) {

    res.status(500).json({
      message: "Server error"
    });

  }

});

// API: Create found item
router.post("/", async (req, res) => {

  try {

    const {
      itemName,
      category,
      description,
      location,
      date,
      reporterName,
      phone,
      email,
      image,
      possession
    } = req.body;

    if (!itemName || !location) {
      return res.status(400).json({
        message: "itemName and location are required"
      });
    }

    const parsedPossession = typeof possession === "boolean" ? possession : null;

    const item = new Item({
      itemName: String(itemName).trim(),
      category: String(category || "Other").trim() || "Other",
      description: String(description || "").trim(),
      location: String(location).trim(),
      date: toSafeDate(date),
      reporterName: String(reporterName || "").trim(),
      phone: String(phone || "").trim(),
      email: String(email || "").trim(),
      image: String(image || "").trim(),
      possession: parsedPossession,
      type: "found"
    });

    const saved = await item.save();
    res.status(201).json(saved);

  } catch (error) {

    res.status(500).json({
      message: "Server error"
    });

  }

});

module.exports = router;
