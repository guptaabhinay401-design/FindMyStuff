const express = require("express");
const router = express.Router();

const Item = require("../models/Item");
const LostItem = require("../models/LostItem");

function toSafeDate(value) {
  if (!value) {
    return new Date();
  }

  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return new Date();
  }

  return parsed;
}

function normalizeLegacyLostItem(item) {
  return {
    _id: item._id,
    itemName: item.itemName,
    category: "Other",
    description: item.description || "",
    type: "lost",
    location: item.location,
    date: item.date || item.createdAt || new Date(),
    reporterName: "",
    phone: "",
    email: "",
    image: "",
    contactPublic: false,
    possession: null,
    createdAt: item.createdAt || item.date || new Date()
  };
}

function sortByDateDesc(items) {
  return items.sort((a, b) => {
    const aTime = new Date(a.date).getTime();
    const bTime = new Date(b.date).getTime();
    return bTime - aTime;
  });
}

// API: Get all lost items
router.get("/", async (req, res) => {

  try {

    const typedItems = await Item
      .find({ type: "lost" })
      .sort({ date: -1 });

    const legacyItems = await LostItem.find().sort({ date: -1 });
    const merged = typedItems.concat(legacyItems.map(normalizeLegacyLostItem));

    res.json(sortByDateDesc(merged));

  } catch (error) {

    res.status(500).json({
      message: "Server error"
    });

  }

});

// API: Get latest lost items
router.get("/recent", async (req, res) => {

  try {

    const requestedLimit = Number.parseInt(req.query.limit, 10);
    const limit = Number.isFinite(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 50) : 8;

    const typedItems = await Item
      .find({ type: "lost" })
      .sort({ date: -1 })
      .limit(limit);

    const legacyItems = await LostItem.find().sort({ date: -1 }).limit(limit);
    const merged = typedItems.concat(legacyItems.map(normalizeLegacyLostItem));

    res.json(sortByDateDesc(merged).slice(0, limit));

  } catch (error) {

    res.status(500).json({
      message: "Server error"
    });

  }

});

// API: Create lost item
router.post("/", async (req, res) => {

  try {

    const {
      itemName,
      category,
      description,
      location,
      date,
      reporterName,
      phone,
      email,
      image,
      contactPublic
    } = req.body;

    if (!itemName || !location) {
      return res.status(400).json({
        message: "itemName and location are required"
      });
    }

    const item = new Item({
      itemName: String(itemName).trim(),
      category: String(category || "Other").trim() || "Other",
      description: String(description || "").trim(),
      location: String(location).trim(),
      date: toSafeDate(date),
      reporterName: String(reporterName || "").trim(),
      phone: String(phone || "").trim(),
      email: String(email || "").trim(),
      image: String(image || "").trim(),
      contactPublic: Boolean(contactPublic),
      type: "lost"
    });

    const saved = await item.save();
    res.status(201).json(saved);

  } catch (error) {

    res.status(500).json({
      message: "Server error"
    });

  }

});

module.exports = router;
